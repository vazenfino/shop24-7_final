import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ProductService } from 'src/app/services/product.services';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit {

  public adminAddForm : FormGroup ;
  public admin:any;
  public isAdminAddSubmitted:boolean;
  constructor(private formBuilder: FormBuilder, private ProductService: ProductService ) { 
    this.adminAddForm = {} as FormGroup ;
    this.admin = {}
    this.isAdminAddSubmitted = false;
  }

  public ngOnInit(): void {
    this.initializeUserForm();
  }

  public initializeUserForm(){
    this.adminAddForm = this.formBuilder.group({
      productName:[''],
      department:[''],
      price:[''],
      discountPrice:[''],
      image:[''],
      description:[''],
      topSelling:[false]
    })
  }

  public onSubmit():void{
    this.isAdminAddSubmitted = true;
    this.admin = this.adminAddForm.getRawValue();
    this.ProductService.adminAddProducts(this.admin).subscribe((response):any =>{
      console.log(response, "reactive form")
    });
  }

}

