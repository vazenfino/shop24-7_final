import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
// import { AlertService } from 'src/app/services/alert.service';
// import { AuthenticationService } from 'src/app/services/authentication.service';
import { UserService } from 'src/app/services/user.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
 public isAddressEditable : boolean;
 public isImageEditable : boolean;
 public profileDetails: any;
  constructor(
    private userService:UserService,
    private router: Router,
    // private alertService: AlertService,
    // private authenticationService: AuthenticationService
  ) { 
    this.isAddressEditable = false;
    this.isImageEditable = false;
  }

  public ngOnInit(): void {
    // const currentUser :any= this.authenticationService.currentUserValue ;
    // this.UserService.getProfile(currentUser).subscribe(
    //   (response:any) => {
    //     this.profileDetails = response.data;
    //     console.log(this.profileDetails)
    //     this.alertService.success('profile loaded successful', true);
    //   },
    //   error => {
    //     this.alertService.error(error);
        
    //   });
  }

  public toggle():void{
    this.isAddressEditable = !this.isAddressEditable;
  }
  public submitProfile(){
    // this.userService.updateProfile(this.profileDetails).subscribe(
    //   data => {
    //     this.profileDetails = data;
    //     this.alertService.success('profile loaded successful', true);
    //   },
    //   error => {
    //     this.alertService.error(error);
        
    //   });
  }

  public editImage():void{
    this.isImageEditable = true;
  }
  public updateImage():void{
    this.isImageEditable = false;
  }
}
