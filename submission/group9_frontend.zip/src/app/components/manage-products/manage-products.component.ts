import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProductDetails } from 'src/app/models/product.model';
import { ProductService } from 'src/app/services/product.services';

@Component({
  selector: 'app-manage-products',
  templateUrl: './manage-products.component.html',
  styleUrls: ['./manage-products.component.css']
})
export class ManageProductsComponent implements OnInit {


  public productDetails: IProductDetails[];
  public filterProduct:string;
  constructor(private productService: ProductService, private router: Router) {
    this.productDetails = [];
    this.filterProduct = '';
   }

   public ngOnInit(): void {
    this.intitializeProductDetails()
  }

  public intitializeProductDetails(){
    this.productService.getProducts().subscribe( (response:IProductDetails[])=>{
      this.productDetails = response;
    })
  }

  public navigateToProductDetails(product : IProductDetails){
    this.router.navigate([''],{
      queryParams:{
    
        productName: product.productName,
        productDept: product.department,
        productPrice: product.price,
        productDiscount: product.discountPrice,
    
        },skipLocationChange:true
    })
  }

  public onDelete(){
    alert("Product Deleted!")
  }


  public onEdit(){
    alert("Product Edited!")
  }
}
