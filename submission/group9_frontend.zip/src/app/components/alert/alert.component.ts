import { Component, OnInit, OnDestroy } from '@angular/core';
import { Subscription } from 'rxjs';
// import { AlertService } from '../../services/alert.service';
import { trigger, style, animate, transition } from '@angular/animations';

const enterTransition = transition(':enter', [
  style({
    opacity: 0
  }),
  animate('1s ease-in', style({
    opacity: 1
  }))
]);

const leaveTrans = transition(':leave', [
  style({
    opacity: 1
  }),
  animate('1s ease-out', style({
    opacity: 0
  }))
])

const fadeIn = trigger('fadeIn', [
  enterTransition
]);

const fadeOut = trigger('fadeOut', [
  leaveTrans
]);
@Component({ 
  selector: 'alert', 
templateUrl: 'alert.component.html',
animations: [
  fadeIn,
  fadeOut
]
})
export class AlertComponent implements OnInit, OnDestroy {
    private subscription: Subscription ={} as Subscription;
    message: any;

    constructor() { }

    ngOnInit() {
        // this.subscription = this.alertService.getAlert()
            // .subscribe(message => {
            //     switch (message && message.type) {
            //         case 'success':
            //             message.cssClass = 'alert alert-success';
            //             break;
            //         case 'error':
            //             message.cssClass = 'alert alert-danger';
            //             break;
            //     }

            //     this.message = message;
            // });
    }

    ngOnDestroy() {
        this.subscription.unsubscribe();
    }
}