import { Component, OnInit } from '@angular/core';
import { IProductDetails } from 'src/app/models/product.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ProductService } from 'src/app/services/product.services';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  public productDetails: IProductDetails[];
  public filterProduct:string;
  constructor(private productService: ProductService, private router: Router) {
    this.productDetails = [];
    this.filterProduct = '';
   }

   public ngOnInit(): void {
    this.intitializeProductDetails()
  }

  public intitializeProductDetails(){
    this.productService.getProducts().subscribe( (response:IProductDetails[])=>{
      this.productDetails = response;
    })
  }

  public navigateToProductDetails(product : IProductDetails){
    this.router.navigate(['/home'],{
      queryParams:{
        productName: product.productName,
        productDept: product.department,
        productPrice: product.price,
        productDiscount: product.discountPrice,
        productImage: product.image,  
        productDescription: product.description,
        productTopSelling: product.topSelling },skipLocationChange:true
    })
  }

}
