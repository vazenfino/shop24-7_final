
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IProductDetails } from 'src/app/models/product.model';
import { ProductService } from 'src/app/services/product.services';

@Component({
  selector: 'app-category-listing',
  templateUrl: './category-listing.component.html',
  styleUrls: ['./category-listing.component.css']
})
export class CategoryListingComponent implements OnInit {

  public productDetails: IProductDetails[];


  constructor(private productService: ProductService, private router: Router) {
    this.productDetails = [];
   
   }

   public ngOnInit(): void {
    this.intitializeProductDetails()
  }

  public intitializeProductDetails(){
    this.productService.getProducts().subscribe( (response:IProductDetails[])=>{
      this.productDetails = response;
    })
  }

  public navigateToProductDetails(product : IProductDetails){
    this.router.navigate([''],{
      queryParams:{
    
        productName: product.productName,
        productDept: product.department,
        productPrice: product.price,
        productDiscount: product.discountPrice,
    
        },skipLocationChange:true
    })
  }

  public onDelete(){
    alert("Product Deleted!")
  }

  public priceRange(x: any, y: any){
    alert("price ")
  }
  public onEdit(){
    alert("Product Edited!")
  }
}


