import { Component, OnInit } from '@angular/core';
// import { AuthenticationService } from 'src/app/services/authentication.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public currentUserRole:string;
  public enableSearchField: boolean;
  constructor(  ) { 
    this.currentUserRole ='';
    this.enableSearchField = false;
    
  }

  public ngOnInit(): void {
    // this.currentUserRole= this.authenticationService.currentUserValue.userrole ;
  }
  public logout() {
 
  }
}
