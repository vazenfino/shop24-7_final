import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IOrderDetails } from 'src/app/models/order.model';
import { OrderService } from 'src/app/services/order.services';

@Component({
  selector: 'app-manage-orders',
  templateUrl: './manage-orders.component.html',
  styleUrls: ['./manage-orders.component.css']
})
export class ManageOrdersComponent implements OnInit {

  public orderDetails: IOrderDetails[];
  public filterProduct:string;
  constructor(private orderService: OrderService, private router: Router) {
    this.orderDetails = [];
    this.filterProduct = '';
   }

   public ngOnInit(): void {
    this.intitializeProductDetails()
  }

  public intitializeProductDetails(){
    this.orderService.getOrders().subscribe( (response:IOrderDetails[])=>{
      this.orderDetails = response;
    })
  }

  public navigateToOrderDetails(order : IOrderDetails){
    this.router.navigate([''],{
      queryParams:{
    
        orderID: order._id,
        orderuserId: order.userId,
        orderEmail:order.userEmail,
        orderIsDelivered:order.isDelivered,
        orderPlacedOn:order.orderPlacedOn,
        orderDeliveredOn:order.orderDeliveredOn
        },skipLocationChange:true
    })
  }

  public onDelete(){
    alert("Order Deleted!")
  }


  public onProcess(){
    alert("Order Edited!")
  }
}
