import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { HomePageComponent } from './components/homepage/homepage.component';
import { ProfileComponent } from './components/profile/profile.component';
import { EditProfileComponent } from './components/edit-profile/edit-profile.component';




import { AddProductComponent } from './components/add-product/add-product.component';
import { ManageProductsComponent } from './components/manage-products/manage-products.component';
import { ManageOrdersComponent } from './components/manage-orders/manage-orders.component';
import { CategoryListingComponent } from './components/category-listing/category-listing.component';

const routes: Routes = [
  {path: "login",component: LoginComponent},
  {path: "register",component: RegisterComponent},
  {path: "homepage",component: HomePageComponent},
  {path: "profile",component: ProfileComponent},
  {path: "editprofile",component: EditProfileComponent},

  {path: "categories/:catergory_id",component: CategoryListingComponent},
  {path: "admin/add-new-product",component: AddProductComponent},
  {path: "admin/products",component: ManageProductsComponent},
  {path: "admin/orders",component: ManageOrdersComponent},

  { path: '**', redirectTo: '/login', pathMatch: 'full' },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
