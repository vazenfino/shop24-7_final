import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IOrderDetails } from '../models/order.model';


@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  public getOrders():Observable<IOrderDetails[]>{
    return this.http.get<IOrderDetails[]>('http://localhost:3000/orders')
  }


  
}
