import { Injectable } from '@angular/core';
import { IProductDetails } from '../models/product.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private http: HttpClient) { }

  public getProducts():Observable<IProductDetails[]>{
    return this.http.get<IProductDetails[]>('http://localhost:3000/products')
  }


  public adminAddProducts(formdata: IProductDetails): Observable<IProductDetails> {
    return this.http.post<any>('http://localhost:3000/admin/add-new-product', formdata)
  }
}
