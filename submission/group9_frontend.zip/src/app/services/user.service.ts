import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IProductDetails } from '../models/product.model';
import { User } from '../models/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {


  constructor(private _httpClient: HttpClient) { }

  public getUsers(): Observable<User[]> {
    return (this._httpClient.get<User[]>('http://localhost:3000/admin/users'))
  }

  public addUser(user: any) {
    return (this._httpClient.post('http://localhost:3000/admin/users/register', user));
  }

  public getUserById(id: any): Observable<User> {
    console.log("ID: " + id);
    return (this._httpClient.get<User>('http://localhost:3000/admin/users/' + id));
  }

  public updateUser(id: any, user: User) {
    return (this._httpClient.put('http://localhost:3000/admin/users/' + id, user));
  }

  public deleteUser(id: any) {
    return (this._httpClient.delete('http://localhost:3000/admin/users/delete/' + id));
  }

  

}
