export interface IOrderDetails{
    _id:$oid[];
    items:[];
    status:Boolean;
    userId:String;
    userEmail:String;
    total:Number;
    isDelivered: Boolean;
    orderDeliveredOn:String;
    orderPlacedOn:String;
}


export interface $oid{
    $oid:String;
}
