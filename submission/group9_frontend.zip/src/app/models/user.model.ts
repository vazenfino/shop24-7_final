export class User{
    firstName!: string;
    lastName!: string;
    username!:string;
    password!:string;
    phone!:number;
    profilePic!:string;
    address!:string;
    admin!: boolean;
}