export interface IProductDetails{
    productName:String;
    department:String;
    price:Number;
    discountPrice:Number;
    image:String;
    description:String;
    topSelling: Boolean
   
}
