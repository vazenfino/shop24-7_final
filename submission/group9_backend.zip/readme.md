1. can skip image and addresse updation skip on 15th.
2. npm angular training day 5
3. node trainingday6 going to route section
4. start server and angular app
5. npm install cors - node 
6. mentions cors on top of srver file and app.use cors demonstartion file: https://codecollab.io/@proj/GreenDeerChannel 
7. node express mongodb
------------------------
1. run mongod driver shell
2. use reference point of day6 node js module and start working on projects parts accordingly

3.coy the package.json from day6 and paste in backend folder and run npm install

4.register api
5. login api
6.profile api direct entry in mongo db or use postman
7. categories api direct entry in mongo db or use postman
8..products api direct entry in mongo db or use postman
8..products paramterized  api direct entry in mongo db or use postman
9 checkout apis
10 order api


Mongodb:
username:root,
pwd:root