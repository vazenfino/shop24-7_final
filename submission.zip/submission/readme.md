

Team 9 Delegation List
----------------------

1.Varun Gaddam
	Category Listing
	Admin Add Product
	Admin Manage Product
	Admin Manage Order
	Backend

2.Jack Owen
	Login
	Registration
	User Profile
	User Edit Profile
	Homepage/header/footer
	

3.Poojith Kumar Gannamaneni

	Product Page
	Cart
	Checkout
	User Orders


